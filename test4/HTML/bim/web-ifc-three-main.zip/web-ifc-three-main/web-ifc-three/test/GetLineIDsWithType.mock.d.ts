/// <reference types="jest" />
import * as WebIFC from "web-ifc";
export declare function mockAndSpyGetLineIDsWithType(api: WebIFC.IfcAPI): jest.SpyInstance<WebIFC.Vector<number>, [modelID: number, type: number]>;
